
update usr set password = md5(password);